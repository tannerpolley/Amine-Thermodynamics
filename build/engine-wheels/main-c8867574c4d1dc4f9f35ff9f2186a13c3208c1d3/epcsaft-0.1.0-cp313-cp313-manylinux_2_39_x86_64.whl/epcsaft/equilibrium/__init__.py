"""Declare native phase, reaction and solid equilibrium calculations.

Use ``Problem`` with explicit temperature (K), pressure (Pa), feed basis and
phase kinds, then call ``solve_equilibrium`` with a fluid model. Solved free phase amounts use mol; pins use dimensionless feed fractions. Total enthalpy and entropy constraints use J
and J/K, respectively; neutral UV uses total internal energy in J and volume in m³ with both T and P free. A returned stopping reason and equation diagnostics
must be inspected before using a solution. Finite phase discovery without a
descent witness is not a global stability certificate (ALG-STABILITY).

Examples
--------
>>> from epcsaft.equilibrium import Free, Pinned
>>> Free(300.0).guess
300.0
>>> Pinned(0.0).value
0.0
"""

from .. import _core
from .problem import (
    _Model,
    Amounts,
    asl_record,
    IdealMoleFraction,
    reaction_activities,
    solid_activities,
    Continuation,
    Discover,
    Feed,
    Free,
    MassFractions,
    Molalities,
    MoleFractions,
    NeutralReference,
    Pinned,
    Phase,
    Problem,
    Reaction,
    Solid,
    tp_flash,
    critical_point,
    bubble_point,
    compile_problem,
    continue_equilibrium,
    dew_point,
    problem_from_mapping,
    solve_equilibrium,
    solve_equilibrium_starts,
    jacobian_table,
    solved_state_actions,
    solved_state_difference,
)

EquilibriumStart = _core.EquilibriumStart
EquilibriumWorkLimits = _core.EquilibriumWorkLimits
EquilibriumStartsResult = _core.EquilibriumStartsResult
inventory_bounds = _core.inventory_bounds
InventoryBound = _core.InventoryBound

EquilibriumResult = _core.EquilibriumResult
TopologyEvent = _core.TopologyEvent
BranchEndCondition = _core.BranchEndCondition
ContinuationResult = _core.ContinuationResult
ContinuationStop = _core.ContinuationStop
SpinodalDeclaration = _core.SpinodalDeclaration
CriticalDeclaration = _core.CriticalDeclaration
EnvelopeCondition = _core.EnvelopeCondition
EnvelopeCoordinate = _core.EnvelopeCoordinate
ReactionLogPolynomial = _core.ReactionLogPolynomial
ReactionReference = _core.ReactionReference
ReferenceSourceBasis = _core.ReferenceSourceBasis
SpeciesReference = _core.SpeciesReference
NeutralReferenceStatus = _core.NeutralReferenceStatus
SolvedStateActionBatch = _core.SolvedStateActionBatch
SolvedStateActionDiagnostics = _core.SolvedStateActionDiagnostics
SolvedStateActionDirection = _core.SolvedStateActionDirection
SolvedStateActionRequest = _core.SolvedStateActionRequest
SolvedStateActionResult = _core.SolvedStateActionResult
SolvedStateActionStatus = _core.SolvedStateActionStatus
SolvedStateObservable = _core.SolvedStateObservable
SolvedStateObservableKind = _core.SolvedStateObservableKind
EOS_STANDARD_STATE_ID = _core.EOS_STANDARD_STATE_ID
IDEAL_MOLE_FRACTION_STANDARD_STATE_ID = _core.IDEAL_MOLE_FRACTION_STANDARD_STATE_ID
IDEAL_MOLARITY_STANDARD_STATE_ID = _core.IDEAL_MOLARITY_STANDARD_STATE_ID
solved_state_first_actions = _core.solved_state_first_actions
cooling_onset = _core.cooling_onset
stability_grid = _core.stability_grid
stability_test = _core.stability_test
StabilityOptions = _core.StabilityOptions
PreparedSuppliedTrials = _core.PreparedSuppliedTrials

def prepare_supplied_trials(model: _Model, temperature: float, trials: list[_core.PhaseSpec]) -> PreparedSuppliedTrials:
    """Prepare ordered supplied points at temperature [K] for this fluid model."""
    return _core.prepare_supplied_trials(model._model, temperature, trials)


Quantity = _core.Quantity
ComparisonMode = _core.ComparisonMode
NumericalEstimate = _core.NumericalEstimate
ComparisonEligibility = _core.ComparisonEligibility
EquilibriumComparison = _core.EquilibriumComparison
EquilibriumNumericalEstimates = _core.EquilibriumNumericalEstimates
compare_equilibrium_quantity = _core.compare_equilibrium_quantity
project_numerical_estimate = _core.project_numerical_estimate


def equilibrium_numerical_estimates(model: _Model | IdealMoleFraction, result: EquilibriumResult) -> EquilibriumNumericalEstimates:
    return _core.equilibrium_numerical_estimates(model._model, result)


__all__ = (
    "Quantity", "ComparisonMode", "NumericalEstimate", "ComparisonEligibility", "EquilibriumComparison",
    "EquilibriumNumericalEstimates", "compare_equilibrium_quantity", "equilibrium_numerical_estimates", "project_numerical_estimate",
    "Amounts",
    "IdealMoleFraction",
    "reaction_activities",
    "solid_activities",
    "IDEAL_MOLE_FRACTION_STANDARD_STATE_ID",
    "IDEAL_MOLARITY_STANDARD_STATE_ID",
    "inventory_bounds",
    "InventoryBound",
    "cooling_onset",
    "stability_grid",
    "stability_test",
    "StabilityOptions",
    "PreparedSuppliedTrials",
    "prepare_supplied_trials",
    "asl_record",
    "Continuation",
    "ContinuationResult",
    "ContinuationStop",
    "CriticalDeclaration",
    "SpinodalDeclaration",
    "EnvelopeCondition",
    "EnvelopeCoordinate",
    "Discover",
    "EOS_STANDARD_STATE_ID",
    "EquilibriumResult",
    "EquilibriumStart",
    "EquilibriumWorkLimits",
    "EquilibriumStartsResult",
    "Feed",
    "Free",
    "MassFractions",
    "Molalities",
    "MoleFractions",
    "NeutralReference",
    "NeutralReferenceStatus",
    "SpeciesReference",
    "Pinned",
    "Phase",
    "Problem",
    "Reaction",
    "ReactionLogPolynomial",
    "ReactionReference",
    "ReferenceSourceBasis",
    "Solid",
    "SolvedStateActionBatch",
    "SolvedStateActionDiagnostics",
    "SolvedStateActionDirection",
    "SolvedStateActionRequest",
    "SolvedStateActionResult",
    "SolvedStateActionStatus",
    "SolvedStateObservable",
    "SolvedStateObservableKind",
    "TopologyEvent",
    "BranchEndCondition",
    "tp_flash",
    "critical_point",
    "bubble_point",
    "compile_problem",
    "continue_equilibrium",
    "dew_point",
    "problem_from_mapping",
    "solve_equilibrium",
    "solve_equilibrium_starts",
    "jacobian_table",
    "solved_state_actions",
    "solved_state_difference",
    "solved_state_first_actions",
)
