"""Verify the extracted MEA handoff and load its parameter mapping."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


root = Path(__file__).resolve().parent
inventory = json.loads((root / "bundle.json").read_text(encoding="utf-8"))
for item in inventory["files"]:
    path = root / item["path"]
    data = path.read_bytes()
    assert len(data) == item["bytes"], item["path"]
    assert hashlib.sha256(data).hexdigest() == item["sha256"], item["path"]

import epcsaft

parameters = epcsaft.Parameters.from_json(root / "parameters/parameters.json")
specs = {spec.identity: spec for spec in parameters.parameter_specs}
assert float(specs["component/carbon-dioxide/dispersion_energy_over_k"].value.magnitude) == 173.44025
assert abs(float(specs["reaction:R4:correlation:a"].value.magnitude) - 3.3515778177997895) < 1e-14
assert float(specs["reaction:R4:correlation:b_k"].value.magnitude) == -1895.3
print("bundle hashes and ePC-SAFT parameter load: ok")
print(f"parameter fingerprint: {parameters.fingerprint}")
