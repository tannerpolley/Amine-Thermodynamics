from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Literal, cast

import pint

from .units import unit_registry


@dataclass(frozen=True, slots=True)
class IdealHeatCapacityPolynomial:
    """Ideal/reference ``cp`` polynomial in ``(T - T_ref) / 1 K``."""

    identity: str
    coefficients_j_per_mol_k: tuple[float, ...]
    temperature_domain_k: tuple[float, float]
    kind: Literal["temperature-polynomial"] = "temperature-polynomial"
    coefficient_unit: Literal["joule / mole / kelvin"] = "joule / mole / kelvin"

    def __post_init__(self) -> None:
        # EqExclude: input and domain validation
        coefficients = tuple(self.coefficients_j_per_mol_k)
        domain = tuple(self.temperature_domain_k)
        object.__setattr__(self, "coefficients_j_per_mol_k", coefficients)
        object.__setattr__(self, "temperature_domain_k", domain)
        if (
            not self.identity
            or self.kind != "temperature-polynomial"
            or self.coefficient_unit != "joule / mole / kelvin"
            or not coefficients
            or any(not math.isfinite(value) for value in coefficients)
            or len(domain) != 2
            or not all(math.isfinite(value) for value in domain)
            or not 0.0 < domain[0] < domain[1]
        ):
            raise ValueError("ideal heat-capacity correlation is incomplete")

    def value(self, temperature_k: float, reference_temperature_k: float) -> float:
        # EqID: ideal_reference_thermochemistry
        self._validate_temperature(temperature_k)
        theta = temperature_k - reference_temperature_k
        try:
            result = math.fsum(
                value * theta**power for power, value in enumerate(self.coefficients_j_per_mol_k)
            )
        except OverflowError as error:
            raise ValueError("ideal heat capacity is non-finite") from error
        if not math.isfinite(result):
            raise ValueError("ideal heat capacity is non-finite")
        return result

    def integral(self, temperature_k: float, reference_temperature_k: float) -> float:
        # EqID: ideal_reference_thermochemistry
        self._validate_temperature(temperature_k)
        theta = temperature_k - reference_temperature_k
        try:
            result = math.fsum(
                value * theta ** (power + 1) / (power + 1)
                for power, value in enumerate(self.coefficients_j_per_mol_k)
            )
        except OverflowError as error:
            raise ValueError("ideal heat-capacity integral is non-finite") from error
        if not math.isfinite(result):
            raise ValueError("ideal heat-capacity integral is non-finite")
        return result

    def _validate_temperature(self, temperature_k: float) -> None:
        # EqExclude: input and domain validation
        if not math.isfinite(temperature_k) or not (
            self.temperature_domain_k[0] <= temperature_k <= self.temperature_domain_k[1]
        ):
            raise ValueError("temperature is outside the ideal heat-capacity domain")


@dataclass(frozen=True, slots=True)
class ComponentReferenceThermochemistry:
    """One component's caller-owned enthalpy reference and ideal heat capacity."""

    component_id: str
    reference_state_id: str
    reference_temperature_k: float
    reference_enthalpy_j_per_mol: float
    heat_capacity: IdealHeatCapacityPolynomial
    temperature_unit: Literal["kelvin"] = "kelvin"
    enthalpy_unit: Literal["joule / mole"] = "joule / mole"

    def __post_init__(self) -> None:
        # EqExclude: input and domain validation
        if (
            not self.component_id
            or not self.reference_state_id
            or self.temperature_unit != "kelvin"
            or self.enthalpy_unit != "joule / mole"
            or not math.isfinite(self.reference_temperature_k)
            or self.reference_temperature_k <= 0.0
            or not math.isfinite(self.reference_enthalpy_j_per_mol)
            or not isinstance(self.heat_capacity, IdealHeatCapacityPolynomial)
            or not (
                self.heat_capacity.temperature_domain_k[0]
                <= self.reference_temperature_k
                <= self.heat_capacity.temperature_domain_k[1]
            )
        ):
            raise ValueError("component reference thermochemistry is incomplete")

    def enthalpy_j_per_mol(self, temperature_k: float) -> float:
        # EqID: ideal_reference_thermochemistry
        result = self.reference_enthalpy_j_per_mol + self.heat_capacity.integral(
            temperature_k, self.reference_temperature_k
        )
        if not math.isfinite(result):
            raise ValueError("component reference enthalpy is non-finite")
        return result


@dataclass(frozen=True, slots=True)
class ReferenceThermochemistry:
    """Explicit component thermochemistry in installed component order."""

    identity: str
    scientific_fingerprint: str
    component_ids: tuple[str, ...]
    components: tuple[ComponentReferenceThermochemistry, ...]

    def __post_init__(self) -> None:
        # EqExclude: input and domain validation
        component_ids = tuple(self.component_ids)
        components = tuple(self.components)
        object.__setattr__(self, "component_ids", component_ids)
        object.__setattr__(self, "components", components)
        if (
            not self.identity
            or len(self.scientific_fingerprint) != 71
            or not self.scientific_fingerprint.startswith("sha256:")
            or any(
                character not in "0123456789abcdef"
                for character in self.scientific_fingerprint.removeprefix("sha256:")
            )
            or not component_ids
            or len(set(component_ids)) != len(component_ids)
            or tuple(item.component_id for item in components) != component_ids
        ):
            raise ValueError("reference thermochemistry order or identity is incomplete")

    def validate_component_order(self, component_ids: tuple[str, ...]) -> None:
        # EqExclude: input and domain validation
        if tuple(component_ids) != self.component_ids:
            raise ValueError("reference thermochemistry component order does not match the EOS")

    def enthalpies_j_per_mol(
        self, temperature_k: float, component_ids: tuple[str, ...]
    ) -> tuple[float, ...]:
        # EqID: ideal_reference_thermochemistry
        self.validate_component_order(component_ids)
        return tuple(item.enthalpy_j_per_mol(temperature_k) for item in self.components)

    def heat_capacities_j_per_mol_k(
        self, temperature_k: float, component_ids: tuple[str, ...]
    ) -> tuple[float, ...]:
        # EqID: ideal_reference_thermochemistry
        self.validate_component_order(component_ids)
        return tuple(
            item.heat_capacity.value(temperature_k, item.reference_temperature_k)
            for item in self.components
        )

    def molar_enthalpy_j_per_mol(
        self,
        temperature_k: float,
        component_ids: tuple[str, ...],
        mole_fractions: tuple[float, ...],
    ) -> float:
        # EqID: complete_molar_enthalpy
        if len(mole_fractions) != len(component_ids):
            raise ValueError("reference thermochemistry composition dimensions differ")
        try:
            result = math.fsum(
                fraction * enthalpy
                for fraction, enthalpy in zip(
                    mole_fractions,
                    self.enthalpies_j_per_mol(temperature_k, component_ids),
                    strict=True,
                )
            )
        except OverflowError as error:
            raise ValueError("mixture reference enthalpy is non-finite") from error
        if not math.isfinite(result):
            raise ValueError("mixture reference enthalpy is non-finite")
        return result

    def molar_heat_capacity_j_per_mol_k(
        self,
        temperature_k: float,
        component_ids: tuple[str, ...],
        mole_fractions: tuple[float, ...],
    ) -> float:
        # EqID: complete_molar_heat_capacity
        if len(mole_fractions) != len(component_ids):
            raise ValueError("reference thermochemistry composition dimensions differ")
        try:
            result = math.fsum(
                fraction * heat_capacity
                for fraction, heat_capacity in zip(
                    mole_fractions,
                    self.heat_capacities_j_per_mol_k(temperature_k, component_ids),
                    strict=True,
                )
            )
        except OverflowError as error:
            raise ValueError("mixture reference heat capacity is non-finite") from error
        if not math.isfinite(result):
            raise ValueError("mixture reference heat capacity is non-finite")
        return result


@dataclass(frozen=True, slots=True)
class PhaseEnthalpy:
    phase_identity: str
    amount_mol: float
    reference_molar_enthalpy_j_per_mol: float
    residual_molar_enthalpy_j_per_mol: float
    molar_enthalpy_j_per_mol: float
    extensive_enthalpy_j: float


@dataclass(frozen=True, slots=True)
class EquilibriumEnthalpy:
    status: Literal["evaluated"]
    value: pint.Quantity[float]
    unit: Literal["joule"]
    reference_identity: str
    reference_fingerprint: str
    parameter_fingerprint: str
    phases: tuple[PhaseEnthalpy, ...]
    active_parameter_fingerprint: str | None = None


def quantity_j_per_mol(value: float) -> pint.Quantity[float]:
    # EqExclude: scalar utility dispatch
    return cast(pint.Quantity[float], value * unit_registry.joule / unit_registry.mole)


__all__ = (
    "ComponentReferenceThermochemistry",
    "EquilibriumEnthalpy",
    "IdealHeatCapacityPolynomial",
    "PhaseEnthalpy",
    "ReferenceThermochemistry",
)
