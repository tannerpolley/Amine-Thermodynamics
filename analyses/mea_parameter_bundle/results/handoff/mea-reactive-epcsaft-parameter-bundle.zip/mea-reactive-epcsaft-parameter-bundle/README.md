# MEA reactive ePC-SAFT parameter bundle

This directory contains the exact nine-species parameter mapping and pinned
ePC-SAFT wheel used by MEA-Thermodynamics on 2026-09-02. It can be used in
absorption-column experiments.

## Scientific use

Verified model choices:

- species: CO2, MEA, H2O, MEAH+, MEACOO-, HCO3-, CO3^2-, H3O+, and OH-;
- reciprocal induced CO2--H2O association and no CO2 self-association;
- Debye--Huckel plus automatically activated corrected SSM+DS electrostatics;
- solvent-only MEA--water mass-fraction relative-permittivity mixing;
- selected R4: ln(K) = 3.3515778178 - 1895.3/T;
- selected CO2 dispersion energy: epsilon/k = 173.44025 K;
- all other coordinates are the values in parameters/parameters.json.

The reaction order, stoichiometry, correlations, units, standard state, and
R1--R3 source-to-common-molality corrections are in
chemistry/reaction-system.json. Compile these correlations at every process
temperature; do not copy an equilibrium-constant value from one validation
state into another temperature.

## Install and verify

Use Python 3.13 on Linux x86_64:

```bash
python3.13 -m venv .venv
.venv/bin/pip install engine/epcsaft-0.2.0.dev0-cp313-cp313-linux_x86_64.whl
.venv/bin/python verify_bundle.py
```

Then load the parameter mapping with:

```python
from pathlib import Path
import epcsaft

root = Path("mea-reactive-epcsaft-parameter-bundle")
parameters = epcsaft.Parameters.from_json(root / "parameters/parameters.json")
model = epcsaft.Mixture(parameters)
```

Construct new column states through `epcsaft.equilibrium` using the species
order and reaction definition in chemistry/reaction-system.json. The retained
validation/state-packet.json is immutable evidence and contains historical
continuation states; do not reuse those continuation states as process-column
initial conditions.

## Fit summary

The automatic-SSM+DS replay evaluates 120/161 pressure states with log10 RMSE
0.4950 and median factor 2.3473. It evaluates 42/44 speciation states and 125
positive targets with log10 RMSE 0.2643. Every one of the 43 failed states is
retained in validation/automatic-extended-full-states.csv.

The populated unique Born diameters and non-unit water solvation factor
activate SSM+DS without separate switches. A zero Born diameter inherits the
same ion diameter used by Debye--Huckel, recovering original Born. The
research notebook records the parameter evidence, structural comparison,
sensitivity results, and next experiments.
