from __future__ import annotations

import csv
import hashlib
import math
from collections.abc import Sequence
from dataclasses import dataclass
from os import PathLike
from pathlib import Path
from typing import cast

import pint

from .._canonical import _canonical_json_bytes
from ..eos import (
    OBSERVABLE_FAMILIES,
    OBSERVABLE_TARGETS,
    EosError,
    Mixture,
    ObservableDescriptor,
    ObservableFamily,
    Pure,
    SaturationError,
    evaluate_observable,
)
from ..parameters import ActiveParameterSet, Parameters
from ..units import unit_registry
from ._model import (
    _CORRELATIONS,
    ActiveSelection,
    EquilibriumFitObservation,
    ObservationSpec,
    ParameterFit,
    PublishedObservationCorrelation,
    QuadratureSpec,
    SourceDomain,
    TableRow,
    TableSource,
)


class FitResolutionError(ValueError):
    def __init__(self, code: str, path: str, detail: object) -> None:
        self.code = code
        self.path = path
        self.detail = detail
        super().__init__(f"{code} at {path}: {detail}")


@dataclass(frozen=True, slots=True)
class SourceCheck:
    path: str
    expected_sha256: str
    actual_sha256: str


@dataclass(frozen=True, slots=True)
class ResolvedCoordinate:
    identity: str
    tied_identities: tuple[str, ...]
    bounds: tuple[float, float]
    origin: float
    scale: float
    unit: str

    @property
    def affine_bounds(self) -> tuple[float, float]:
        return (
            (self.bounds[0] - self.origin) / self.scale,
            (self.bounds[1] - self.origin) / self.scale,
        )


@dataclass(frozen=True, slots=True)
class QuadratureRule:
    order: int
    nodes: tuple[float, ...]
    weights: tuple[float, ...]
    observed_values: tuple[float, ...]
    observed_derivatives: tuple[float, ...]


@dataclass(frozen=True, slots=True)
class QuadraturePlan:
    correlation: str
    domain: SourceDomain
    measure: str
    controls: QuadratureSpec
    rules: tuple[QuadratureRule, ...]
    accepted_order: int
    normalized_objective: float
    objective_jacobian: tuple[float, ...]
    objective_change: float
    jacobian_change: float


@dataclass(frozen=True, slots=True)
class ResolvedObservation:
    specification: ObservationSpec
    descriptor: ObservableDescriptor
    canonical_units: tuple[tuple[str, str], ...]
    rows: tuple[TableRow, ...] | None
    source_check: SourceCheck
    quadrature: QuadraturePlan | None


@dataclass(frozen=True, slots=True)
class ResolvedFit:
    fit: ParameterFit
    parameters: Parameters
    active_parameters: ActiveParameterSet
    selected_identities: tuple[str, ...]
    independent_identities: tuple[str, ...]
    coordinates: tuple[ResolvedCoordinate, ...]
    observations: tuple[ResolvedObservation, ...]
    parameters_source_check: SourceCheck
    digest: str

    @property
    def source_checks(self) -> tuple[SourceCheck, ...]:
        return (
            self.parameters_source_check,
            *(observation.source_check for observation in self.observations),
        )

    def to_mapping(self) -> dict[str, object]:
        fit_observations = self.fit.to_mapping()["observations"]
        assert isinstance(fit_observations, list)
        return {
            "fit": self.fit.to_mapping(),
            "parameters_fingerprint": self.parameters.fingerprint,
            "parameters_source_check": _source_check_mapping(self.parameters_source_check),
            "active_parameter_fingerprint": self.active_parameters.fingerprint,
            "selected_identities": list(self.selected_identities),
            "independent_identities": list(self.independent_identities),
            "coordinates": [
                {
                    "identity": coordinate.identity,
                    "tied_identities": list(coordinate.tied_identities),
                    "bounds": list(coordinate.bounds),
                    "origin": coordinate.origin,
                    "affine_bounds": list(coordinate.affine_bounds),
                    "scale": coordinate.scale,
                    "unit": coordinate.unit,
                }
                for coordinate in self.coordinates
            ],
            "observations": [
                {
                    "specification": fit_observations[index],
                    "descriptor": _descriptor_mapping(observation.descriptor),
                    "canonical_units": dict(observation.canonical_units),
                    "rows": None
                    if observation.rows is None
                    else [{name: value for name, value in row.values} for row in observation.rows],
                    "source_check": _source_check_mapping(observation.source_check),
                    "quadrature": _quadrature_mapping(observation.quadrature),
                }
                for index, observation in enumerate(self.observations)
            ],
        }


def _hash(value: object) -> str:
    return f"sha256:{hashlib.sha256(_canonical_json_bytes(value)).hexdigest()}"


def _path_root(base_path: str | PathLike[str] | None) -> Path:
    if base_path is None:
        return Path.cwd()
    candidate = Path(base_path)
    if candidate.is_dir():
        return candidate
    return candidate.parent


def _local_path(path: str, root: Path) -> Path:
    target = Path(path)
    return target if target.is_absolute() else root / target


def _file_check(
    path: str,
    expected: str,
    *,
    root: Path,
    inline: object | None = None,
) -> SourceCheck:
    if inline is not None:
        actual = _hash(inline)
    else:
        target = _local_path(path, root)
        if not target.is_file():
            raise FitResolutionError("source-missing", path, str(target))
        try:
            actual = f"sha256:{hashlib.sha256(target.read_bytes()).hexdigest()}"
        except OSError as exc:
            raise FitResolutionError("source-read", path, str(exc)) from exc
    if actual != expected:
        raise FitResolutionError(
            "source-digest-mismatch", path, {"expected": expected, "actual": actual}
        )
    return SourceCheck(path, expected, actual)


def _verify_parameters_reference(fit: ParameterFit, parameters: Parameters, root: Path) -> None:
    target = _local_path(fit.parameters.path, root)
    try:
        referenced = Parameters.from_json(target, components=parameters.component_ids)
    except (OSError, ValueError) as exc:
        raise FitResolutionError(
            "invalid-parameters-source", fit.parameters.path, str(exc)
        ) from exc
    if referenced.fingerprint != parameters.fingerprint:
        raise FitResolutionError(
            "parameters-fingerprint-mismatch",
            fit.parameters.path,
            {
                "declared": referenced.fingerprint,
                "provided": parameters.fingerprint,
            },
        )


def _source_check_mapping(check: SourceCheck) -> dict[str, object]:
    return {
        "path": check.path,
        "expected_sha256": check.expected_sha256,
        "actual_sha256": check.actual_sha256,
    }


def _descriptor_mapping(descriptor: ObservableDescriptor) -> dict[str, object]:
    return {
        "identity": descriptor.identity,
        "version": descriptor.version,
        "required_inputs": list(descriptor.required_inputs),
        "applicability": descriptor.applicability,
        "model_identity": descriptor.model_identity,
        "supported_topologies": list(descriptor.supported_topologies),
        "model_domain": descriptor.model_domain,
        "temperature_domain_k": list(descriptor.temperature_domain_k),
        "row_identities": list(descriptor.row_identities),
        "row_units": list(descriptor.row_units),
        "row_bases": list(descriptor.row_bases),
        "state_fields": list(descriptor.state_fields),
        "reference": descriptor.reference,
        "active_parameter_identities": list(descriptor.active_parameter_identities),
        "active_parameter_values": list(descriptor.active_parameter_values),
        "active_parameter_units": list(descriptor.active_parameter_units),
        "derivative_orders": list(descriptor.derivative_orders),
        "source_derivative_order": descriptor.source_derivative_order,
        "jacobian_shape": list(descriptor.jacobian_shape),
        "jacobian_axes": list(descriptor.jacobian_axes),
        "jacobian_layout": descriptor.jacobian_layout,
        "parameter_fingerprint": descriptor.parameter_fingerprint,
        "active_parameter_fingerprint": descriptor.active_parameter_fingerprint,
        "topology_fingerprint": descriptor.topology_fingerprint,
    }


def _quadrature_mapping(quadrature: QuadraturePlan | None) -> dict[str, object] | None:
    if quadrature is None:
        return None
    return {
        "correlation": quadrature.correlation,
        "domain": {name: list(bounds) for name, bounds in quadrature.domain.bounds},
        "measure": quadrature.measure,
        "controls": {
            "initial_order": quadrature.controls.initial_order,
            "max_order": quadrature.controls.max_order,
            "tolerance": quadrature.controls.tolerance,
        },
        "rules": [
            {
                "order": rule.order,
                "nodes": list(rule.nodes),
                "weights": list(rule.weights),
                "observed_values": list(rule.observed_values),
                "observed_derivatives": list(rule.observed_derivatives),
            }
            for rule in quadrature.rules
        ],
        "accepted_order": quadrature.accepted_order,
        "normalized_objective": quadrature.normalized_objective,
        "objective_jacobian": list(quadrature.objective_jacobian),
        "objective_change": quadrature.objective_change,
        "jacobian_change": quadrature.jacobian_change,
    }


def _selected_identities(fit: ParameterFit, parameters: Parameters) -> tuple[str, ...]:
    specs = tuple(parameters.parameter_specs)
    available = {spec.identity: spec for spec in specs}
    if len(available) != len(specs):
        raise FitResolutionError("duplicate-parameter", "parameters.parameter_specs", None)
    selected = fit.active.identities
    missing = tuple(identity for identity in selected if identity not in available)
    if missing:
        raise FitResolutionError("missing-parameter", "$.active.identities", missing)
    for identity in selected:
        spec = available[identity]
        if spec.continuous is not True:
            raise FitResolutionError("discrete-parameter", identity, spec.family)
    try:
        ActiveParameterSet(parameters, selected)
    except ValueError as exc:
        raise FitResolutionError(
            "invalid-active-parameter-set", "$.active.identities", str(exc)
        ) from exc
    return selected


def _tie_groups(
    selection: ActiveSelection, selected: tuple[str, ...]
) -> tuple[tuple[str, ...], ...]:
    selected_set = set(selected)
    memberships: dict[str, int] = {}
    for index, tie in enumerate(selection.ties):
        for identity in tie.identities:
            if identity not in selected_set:
                raise FitResolutionError("tie-outside-selection", "$.active.ties", identity)
            if identity in memberships:
                raise FitResolutionError("overlapping-tie", "$.active.ties", identity)
            memberships[identity] = index
    groups: list[tuple[str, ...]] = []
    emitted: set[int] = set()
    for identity in selected:
        tie_index = memberships.get(identity)
        if tie_index is None:
            groups.append((identity,))
            continue
        if tie_index in emitted:
            continue
        members = tuple(member for member in selected if memberships.get(member) == tie_index)
        groups.append(members)
        emitted.add(tie_index)
    return tuple(groups)


def _resolve_coordinates(
    fit: ParameterFit,
    parameters: Parameters,
    selected: tuple[str, ...],
) -> tuple[tuple[str, ...], tuple[ResolvedCoordinate, ...]]:
    specs = {spec.identity: spec for spec in parameters.parameter_specs}
    declared = dict(fit.active.coordinates)
    groups = _tie_groups(fit.active, selected)
    representatives = {group[0] for group in groups}
    unexpected = tuple(sorted(set(declared) - representatives))
    if unexpected:
        raise FitResolutionError("coordinate-not-independent", "$.active.coordinates", unexpected)
    independent: list[str] = []
    coordinates: list[ResolvedCoordinate] = []
    for group in groups:
        representative = group[0]
        coordinate = declared.get(representative)
        if coordinate is None:
            raise FitResolutionError("missing-coordinate", "$.active.coordinates", representative)
        if coordinate.bounds[0] >= coordinate.bounds[1]:
            raise FitResolutionError(
                "invalid-bounds", f"$.active.coordinates.{representative}", coordinate.bounds
            )
        parameter_units = tuple(str(specs[identity].unit) for identity in group)
        if len(set(parameter_units)) != 1:
            raise FitResolutionError("incompatible-tie-units", representative, parameter_units)
        unit = coordinate.unit or parameter_units[0]
        try:
            unit_registry.Quantity(1, unit).to(parameter_units[0])
        except (AttributeError, TypeError, ValueError, pint.errors.PintError) as exc:
            raise FitResolutionError(
                "unit-mismatch",
                f"$.active.coordinates.{representative}.unit",
                {"declared": unit, "parameter": parameter_units[0]},
            ) from exc
        if not coordinate.bounds[0] <= coordinate.origin <= coordinate.bounds[1]:
            raise FitResolutionError(
                "origin-outside-bounds", f"$.active.coordinates.{representative}", coordinate.origin
            )
        independent.append(representative)
        coordinates.append(
            ResolvedCoordinate(
                representative,
                group,
                coordinate.bounds,
                coordinate.origin,
                coordinate.scale,
                unit,
            )
        )
    for start_index, start in enumerate(fit.solver.multistart.starts):
        if len(start.values) != len(coordinates):
            raise FitResolutionError(
                "invalid-start-dimension",
                f"$.solver.multistart.starts[{start_index}].values",
                {"expected": len(coordinates), "actual": len(start.values)},
            )
        for coordinate_index, (value, start_coordinate) in enumerate(
            zip(start.values, coordinates, strict=True)
        ):
            lower, upper = start_coordinate.bounds
            if not lower <= value <= upper:
                raise FitResolutionError(
                    "start-outside-bounds",
                    f"$.solver.multistart.starts[{start_index}].values[{coordinate_index}]",
                    value,
                )
    coordinate_by_parameter = {
        identity: coordinate
        for coordinate in coordinates
        for identity in coordinate.tied_identities
    }
    for label, values in (
        ("lower", {item.identity: item.bounds[0] for item in coordinates}),
        ("origin", {item.identity: item.origin for item in coordinates}),
        ("upper", {item.identity: item.bounds[1] for item in coordinates}),
    ):
        try:
            ActiveParameterSet(
                parameters,
                selected,
                values=tuple(
                    values[coordinate_by_parameter[identity].identity] for identity in selected
                ),
            )
        except ValueError as exc:
            raise FitResolutionError(
                "coordinate-outside-parameter-domain", f"$.active.coordinates.{label}", str(exc)
            ) from exc
    for start_index, start in enumerate(fit.solver.multistart.starts):
        physical = dict(zip(independent, start.values, strict=True))
        try:
            ActiveParameterSet(
                parameters,
                selected,
                values=tuple(
                    physical[coordinate_by_parameter[identity].identity] for identity in selected
                ),
            )
        except ValueError as exc:
            raise FitResolutionError(
                "start-outside-parameter-domain",
                f"$.solver.multistart.starts[{start_index}]",
                str(exc),
            ) from exc
    return tuple(independent), tuple(coordinates)


def _table_rows(
    source: TableSource,
    *,
    root: Path,
    definition: ObservableFamily,
    targets: tuple[str, ...],
) -> tuple[TableRow, ...]:
    if source.rows is not None:
        return source.rows
    target = Path(source.path)
    if not target.is_absolute():
        target = root / target
    if not target.is_file():
        raise FitResolutionError("source-missing", source.path, str(target))
    try:
        with target.open(newline="", encoding="utf-8") as handle:
            reader = csv.DictReader(handle)
            fields = tuple(reader.fieldnames or ())
            expected = (*definition.state_fields, *targets)
            if len(fields) != len(set(fields)) or set(fields) != set(expected):
                raise FitResolutionError(
                    "table-columns", source.path, {"expected": expected, "actual": fields}
                )
            rows: list[TableRow] = []
            for index, raw in enumerate(reader):
                if None in raw:
                    raise FitResolutionError(
                        "table-columns",
                        f"{source.path}[{index}]",
                        {"unexpected": raw[None]},
                    )
                values: list[tuple[str, float]] = []
                for name in sorted(expected):
                    value = raw.get(name)
                    if value is None or value == "":
                        raise FitResolutionError(
                            "table-value", f"{source.path}[{index}].{name}", "missing"
                        )
                    try:
                        number = float(value)
                    except ValueError as exc:
                        raise FitResolutionError(
                            "table-value", f"{source.path}[{index}].{name}", value
                        ) from exc
                    if not math.isfinite(number):
                        raise FitResolutionError(
                            "table-value", f"{source.path}[{index}].{name}", value
                        )
                    values.append((name, number))
                rows.append(TableRow(tuple(values)))
    except OSError as exc:
        raise FitResolutionError("source-read", source.path, str(exc)) from exc
    if not rows:
        raise FitResolutionError("table-empty", source.path, None)
    return tuple(rows)


def _validate_rows(rows: Sequence[TableRow], source: TableSource, targets: tuple[str, ...]) -> None:
    states: set[tuple[float, ...]] = set()
    state_fields = tuple(name for name, _ in source.domain.bounds)
    for index, row in enumerate(rows):
        state = tuple(row.value(name) for name in state_fields)
        if state in states:
            raise FitResolutionError("duplicate-state", f"{source.path}[{index}]", state)
        states.add(state)
        for name, (lower, upper) in source.domain.bounds:
            value = row.value(name)
            if not lower <= value <= upper:
                raise FitResolutionError(
                    "row-outside-domain", f"{source.path}[{index}].{name}", value
                )
        for target in targets:
            value = row.value(target)
            if OBSERVABLE_TARGETS[target].positive and value <= 0:
                raise FitResolutionError(
                    "nonpositive-target", f"{source.path}[{index}].{target}", value
                )


def _validate_observation(
    observation: ObservationSpec, descriptor: ObservableDescriptor
) -> tuple[tuple[tuple[str, str], ...], tuple[tuple[str, float], ...]]:
    descriptor_rows = {
        label: unit
        for label, unit in zip(descriptor.row_identities, descriptor.row_units, strict=True)
    }
    unsupported_targets = tuple(
        target
        for target in observation.targets
        if OBSERVABLE_TARGETS[target].row_identity not in descriptor_rows
    )
    if unsupported_targets:
        raise FitResolutionError(
            "unsupported-observation-target", observation.family, unsupported_targets
        )
    for name, (lower, upper) in observation.source.domain.bounds:
        if lower >= upper or (name == "temperature_k" and lower <= 0):
            raise FitResolutionError(
                "invalid-domain", f"{observation.source.path}.{name}", (lower, upper)
            )
        if name == "temperature_k":
            model_lower, model_upper = descriptor.temperature_domain_k
            if (model_lower is not None and lower < model_lower) or (
                model_upper is not None and upper > model_upper
            ):
                raise FitResolutionError(
                    "source-outside-model-domain",
                    f"{observation.source.path}.{name}",
                    {
                        "source": (lower, upper),
                        "model": descriptor.temperature_domain_k,
                    },
                )
    canonical_units: list[tuple[str, str]] = []
    factors: list[tuple[str, float]] = []
    for target, unit in observation.units:
        canonical_unit = descriptor_rows[OBSERVABLE_TARGETS[target].row_identity]
        try:
            zero = float(unit_registry.Quantity(0, unit).to(canonical_unit).magnitude)
            factor = float(unit_registry.Quantity(1, unit).to(canonical_unit).magnitude)
        except (AttributeError, TypeError, ValueError, pint.errors.PintError) as exc:
            raise FitResolutionError("invalid-unit", target, unit) from exc
        if zero != 0.0 or not math.isfinite(factor) or factor <= 0.0:
            raise FitResolutionError("invalid-unit", target, unit)
        canonical_units.append((target, canonical_unit))
        factors.append((target, factor))
    return tuple(canonical_units), tuple(factors)


def _canonical_rows(rows: Sequence[TableRow], factors: dict[str, float]) -> tuple[TableRow, ...]:
    converted: list[TableRow] = []
    for index, row in enumerate(rows):
        values = tuple((name, value * factors.get(name, 1.0)) for name, value in row.values)
        if not all(math.isfinite(value) for _, value in values):
            raise FitResolutionError("unit-conversion-nonfinite", f"rows[{index}]", None)
        converted.append(TableRow(values))
    return tuple(converted)


def _gauss_legendre(order: int) -> tuple[tuple[float, ...], tuple[float, ...]]:
    nodes = [0.0] * order
    weights = [0.0] * order
    for index in range((order + 1) // 2):
        root = math.cos(math.pi * (index + 0.75) / (order + 0.5))
        for _ in range(64):
            p_previous, p_current = 1.0, root
            for degree in range(2, order + 1):
                p_previous, p_current = (
                    p_current,
                    ((2 * degree - 1) * root * p_current - (degree - 1) * p_previous) / degree,
                )
            derivative = order * (root * p_current - p_previous) / (root * root - 1.0)
            step = p_current / derivative
            root -= step
            if abs(step) <= 2.0e-15:
                break
        p_previous, p_current = 1.0, root
        for degree in range(2, order + 1):
            p_previous, p_current = (
                p_current,
                ((2 * degree - 1) * root * p_current - (degree - 1) * p_previous) / degree,
            )
        derivative = order * (root * p_current - p_previous) / (root * root - 1.0)
        nodes[index] = -root
        nodes[order - index - 1] = root
        weight = 2.0 / ((1.0 - root * root) * derivative * derivative)
        weights[index] = weight
        weights[order - index - 1] = weight
    return tuple(nodes), tuple(weights)


def _transformed_input(kind: str, temperature_k: float) -> tuple[float, float]:
    if kind == "identity":
        return temperature_k, 1.0
    if kind == "log":
        return math.log(temperature_k), 1.0 / temperature_k
    if kind == "log10":
        return math.log10(temperature_k), 1.0 / (temperature_k * math.log(10.0))
    raise RuntimeError(f"unhandled input transformation: {kind}")


def _transformed_output(kind: str, value: float) -> tuple[float, float]:
    if kind == "identity":
        return value, 1.0
    if kind == "log":
        result = math.exp(value)
        return result, result
    if kind == "log10":
        result = 10.0**value
        return result, math.log(10.0) * result
    raise RuntimeError(f"unhandled output transformation: {kind}")


def _correlation_value_derivative(
    source: PublishedObservationCorrelation,
    observation: ObservationSpec,
    temperature_k: float,
) -> tuple[float, float]:
    definition = _CORRELATIONS[source.correlation]
    transformation = dict(observation.transformation)[observation.targets[0]]
    try:
        independent, independent_derivative = _transformed_input(
            transformation.input, temperature_k
        )
        if definition.form != "power_series":
            raise RuntimeError(f"unhandled correlation form: {definition.form}")
        value = source.coefficients[-1]
        derivative = 0.0
        for coefficient in reversed(source.coefficients[:-1]):
            derivative = derivative * independent + value
            value = value * independent + coefficient
        observed, output_derivative = _transformed_output(transformation.output, value)
        derivative *= independent_derivative * output_derivative
    except (OverflowError, ValueError, ZeroDivisionError) as exc:
        raise FitResolutionError(
            "correlation-numerical", source.correlation, temperature_k
        ) from exc
    if not math.isfinite(observed) or not math.isfinite(derivative):
        raise FitResolutionError("correlation-nonfinite", source.correlation, temperature_k)
    target = OBSERVABLE_TARGETS[observation.targets[0]]
    if target.positive and observed <= 0:
        raise FitResolutionError("correlation-nonpositive", source.correlation, temperature_k)
    return observed, derivative


def _quadrature_objective(
    rule: QuadratureRule,
    observation: ObservationSpec,
    model: Pure,
    active_parameters: ActiveParameterSet,
) -> tuple[float, tuple[float, ...]]:
    target = observation.targets[0]
    label = OBSERVABLE_TARGETS[target].row_identity
    residual_kind = dict(observation.residuals)[target]
    if residual_kind != "log_ratio":
        raise RuntimeError(f"unhandled residual: {residual_kind}")
    try:
        descriptor = model.observable_descriptor(
            active_parameters,
            identity=OBSERVABLE_FAMILIES[observation.family].descriptor_identity,
        )
    except EosError as exc:
        raise FitResolutionError(
            "quadrature-evaluation", observation.source.path, "descriptor"
        ) from exc
    residuals: list[float] = []
    jacobian: list[tuple[float, ...]] = []
    for temperature_k, observed in zip(rule.nodes, rule.observed_values, strict=True):
        try:
            result = evaluate_observable(
                model,
                active_parameters,
                descriptor,
                {"temperature_k": temperature_k},
                composition=observation.composition,
            )
            rows = {
                identity: (value, derivatives, status)
                for identity, value, derivatives, status in zip(
                    result.descriptor.row_identities,
                    result.values,
                    result.jacobian,
                    result.row_statuses,
                    strict=True,
                )
            }
        except (EosError, SaturationError, ValueError) as exc:
            raise FitResolutionError(
                "quadrature-evaluation", observation.source.path, temperature_k
            ) from exc
        row = rows.get(label)
        predicted = None if row is None else row[0]
        derivative_row = None if row is None else row[1]
        if (
            result.status.status != "accepted"
            or row is None
            or row[2].status != "accepted"
            or predicted is None
            or derivative_row is None
            or not math.isfinite(predicted)
            or predicted <= 0
        ):
            raise FitResolutionError(
                "quadrature-evaluation", observation.source.path, temperature_k
            )
        residuals.append(observation.multiplier * math.log(predicted / observed))
        jacobian.append(
            tuple(observation.multiplier * derivative / predicted for derivative in derivative_row)
        )
    objective = sum(
        weight * residual * residual
        for weight, residual in zip(rule.weights, residuals, strict=True)
    )
    objective_jacobian = tuple(
        2.0
        * sum(
            weight * residual * row[column]
            for weight, residual, row in zip(rule.weights, residuals, jacobian, strict=True)
        )
        for column in range(len(active_parameters.identities))
    )
    if not math.isfinite(objective) or not all(
        math.isfinite(value) for value in objective_jacobian
    ):
        raise FitResolutionError("quadrature-numerical", observation.source.path, rule.order)
    return objective, objective_jacobian


def _relative_change(current: float, previous: float) -> float:
    return abs(current - previous) / max(1.0, abs(current), abs(previous))


def _quadrature(
    observation: ObservationSpec,
    model: Pure,
    active_parameters: ActiveParameterSet,
    unit_factor: float,
) -> QuadraturePlan | None:
    source = observation.source
    controls = observation.quadrature
    if not isinstance(source, PublishedObservationCorrelation) or controls is None:
        return None
    if controls.initial_order > controls.max_order:
        raise FitResolutionError(
            "invalid-quadrature", source.correlation, "initial order exceeds maximum"
        )
    lower, upper = source.domain.value("temperature_k")
    midpoint = (lower + upper) / 2.0
    half_width = (upper - lower) / 2.0
    rules: list[QuadratureRule] = []
    previous_objective: float | None = None
    previous_jacobian: tuple[float, ...] | None = None
    last_changes: tuple[float, float] | None = None
    order = controls.initial_order
    while order <= controls.max_order:
        reference_nodes, reference_weights = _gauss_legendre(order)
        nodes = tuple(midpoint + half_width * node for node in reference_nodes)
        values_and_derivatives = tuple(
            _correlation_value_derivative(source, observation, node) for node in nodes
        )
        rule = QuadratureRule(
            order,
            nodes,
            tuple(weight / 2.0 for weight in reference_weights),
            tuple(value * unit_factor for value, _ in values_and_derivatives),
            tuple(derivative * unit_factor for _, derivative in values_and_derivatives),
        )
        rules.append(rule)
        objective, objective_jacobian = _quadrature_objective(
            rule, observation, model, active_parameters
        )
        if previous_objective is not None and previous_jacobian is not None:
            objective_change = _relative_change(objective, previous_objective)
            jacobian_change = max(
                (
                    _relative_change(current, previous)
                    for current, previous in zip(objective_jacobian, previous_jacobian, strict=True)
                ),
                default=0.0,
            )
            last_changes = (objective_change, jacobian_change)
            if max(last_changes) <= controls.tolerance:
                return QuadraturePlan(
                    source.correlation,
                    source.domain,
                    "uniform_temperature",
                    controls,
                    tuple(rules),
                    order,
                    objective,
                    objective_jacobian,
                    objective_change,
                    jacobian_change,
                )
        previous_objective = objective
        previous_jacobian = objective_jacobian
        order *= 2
    raise FitResolutionError(
        "quadrature-not-converged",
        source.correlation,
        {
            "max_order": controls.max_order,
            "tolerance": controls.tolerance,
            "changes": last_changes,
        },
    )


def resolve_fit(
    fit: ParameterFit,
    parameters: Parameters,
    *,
    base_path: str | PathLike[str] | None = None,
) -> ResolvedFit:
    if not isinstance(fit, ParameterFit):
        raise FitResolutionError("invalid-fit", "fit", type(fit).__name__)
    if not isinstance(parameters, Parameters):
        raise FitResolutionError("invalid-parameters", "parameters", type(parameters).__name__)
    component_count = len(parameters.component_ids)
    if fit.model.kind == "pure" and component_count != 1:
        raise FitResolutionError("model-cardinality", "$.model.kind", component_count)
    if fit.model.kind == "mixture" and component_count < 2:
        raise FitResolutionError("model-cardinality", "$.model.kind", component_count)

    root = _path_root(base_path)
    parameters_source_check = _file_check(
        fit.parameters.path,
        fit.parameters.sha256,
        root=root,
    )
    _verify_parameters_reference(fit, parameters, root)
    selected = _selected_identities(fit, parameters)
    independent, coordinates = _resolve_coordinates(fit, parameters, selected)
    active_parameters = ActiveParameterSet(parameters, selected)
    model = Pure(parameters) if fit.model.kind == "pure" else Mixture(parameters)
    resolved_observations: list[ResolvedObservation] = []
    for index, observation in enumerate(fit.observations):
        if isinstance(observation, EquilibriumFitObservation):
            continue
        if fit.model.kind == "mixture":
            if observation.composition is None or len(observation.composition) != component_count:
                raise FitResolutionError(
                    "invalid-composition", f"$.observations[{index}].composition", component_count
                )
        elif observation.composition is not None:
            raise FitResolutionError(
                "invalid-composition", f"$.observations[{index}].composition", "pure model"
            )
        definition = OBSERVABLE_FAMILIES[observation.family]
        try:
            descriptor = model.observable_descriptor(
                active_parameters,
                identity=definition.descriptor_identity,
            )
        except EosError as exc:
            raise FitResolutionError(
                "unsupported-parameter-derivative", observation.family, str(exc)
            ) from exc
        canonical_units, unit_factors = _validate_observation(observation, descriptor)
        factors = dict(unit_factors)
        source = observation.source
        if isinstance(source, PublishedObservationCorrelation) and not isinstance(model, Pure):
            raise FitResolutionError(
                "unsupported-source", f"$.observations[{index}].source", "mixture correlation"
            )
        if isinstance(source, TableSource):
            inline_rows = (
                None
                if source.rows is None
                else [{name: value for name, value in row.values} for row in source.rows]
            )
            check = _file_check(
                source.path,
                source.sha256,
                root=root,
                inline=inline_rows,
            )
            rows = _table_rows(
                source,
                root=root,
                definition=definition,
                targets=observation.targets,
            )
            _validate_rows(rows, source, observation.targets)
            rows = _canonical_rows(rows, factors)
        else:
            correlation_payload = {
                "correlation": source.correlation,
                "coefficients": list(source.coefficients),
                "domain": {name: list(bounds) for name, bounds in source.domain.bounds},
            }
            check = _file_check(
                source.path,
                source.sha256,
                root=root,
                inline=correlation_payload,
            )
            rows = None
        resolved_observations.append(
            ResolvedObservation(
                observation,
                descriptor,
                canonical_units,
                rows,
                check,
                _quadrature(
                    observation,
                    cast(Pure, model),
                    active_parameters,
                    factors[observation.targets[0]],
                ),
            )
        )

    provisional = ResolvedFit(
        fit,
        parameters,
        active_parameters,
        selected,
        independent,
        coordinates,
        tuple(resolved_observations),
        parameters_source_check,
        "",
    )
    return ResolvedFit(
        provisional.fit,
        provisional.parameters,
        provisional.active_parameters,
        provisional.selected_identities,
        provisional.independent_identities,
        provisional.coordinates,
        provisional.observations,
        provisional.parameters_source_check,
        _hash(provisional.to_mapping()),
    )
