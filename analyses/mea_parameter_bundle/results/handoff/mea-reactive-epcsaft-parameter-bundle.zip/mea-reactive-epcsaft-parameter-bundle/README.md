# MEA reactive ePC-SAFT parameter bundle

This directory contains the exact nine-species parameter mapping and pinned
ePC-SAFT wheel used by MEA-Thermodynamics on 2026-09-02. It can be used in
absorption-column experiments.

## Scientific use

Verified model choices:

- species: CO2, MEA, H2O, MEAH+, MEACOO-, HCO3-, CO3^2-, H3O+, and OH-;
- reciprocal induced CO2--H2O association and no CO2 self-association;
- Debye--Huckel plus original Born electrostatics;
- Uyan solvent-only MEA--water relative-permittivity mixing;
- selected R4: ln(K) = 3.3515778178 - 1895.3/T;
- selected CO2 dispersion energy: epsilon/k = 173.44025 K;
- all other coordinates are the values in parameters/parameters.json.

The reaction order, stoichiometry, correlations, units, standard state, and
R1--R3 source-to-common-molality corrections are in
chemistry/reaction-system.json. Compile these correlations at every process
temperature; do not copy an equilibrium-constant value from one validation
state into another temperature.

## Install and verify

Use Python 3.13 on Linux x86_64:

```bash
python3.13 -m venv .venv
.venv/bin/pip install engine/epcsaft-0.2.0.dev0-cp313-cp313-linux_x86_64.whl
.venv/bin/python verify_bundle.py
```

Then load the parameter mapping with:

```python
from pathlib import Path
import epcsaft

root = Path("mea-reactive-epcsaft-parameter-bundle")
parameters = epcsaft.Parameters.from_json(root / "parameters/parameters.json")
model = epcsaft.Mixture(parameters)
```

Construct new column states through `epcsaft.equilibrium` using the species
order and reaction definition in chemistry/reaction-system.json. The retained
validation/state-packet.json is immutable evidence and contains historical
continuation states; do not reuse those continuation states as process-column
initial conditions.

## Fit summary

Relative to the previous parameter set:

- pressure log10 RMSE improved from 0.3974 to 0.3540;
- temperature-balanced pressure log10 RMSE improved from 0.3569 to 0.3185;
- pressure coverage improved from 125/161 to 130/161 states;
- all 131/131 observed speciation targets evaluated, with log10 RMSE 0.2658.

The pressure residual remains temperature-dependent: the model overpredicts
at 40--60 C and underpredicts at 80--120 C. Only 12/39 pressure states at
120 C evaluated. The 31 states listed in validation/non-evaluable-states.csv
did not solve and should remain marked as such. Record any change to the vapor
model, species set, or reaction standard state separately.

The numerical authority is validation/fit-residuals.csv. The
research notebook records the parameter evidence, bounded campaign, and next
experiments.
